#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

int numberOfReads = 0;
int numberOfWrites = 0;
int numberOfHits = 0;
int numberOfMisses = 0;

typedef struct node {
    long unsigned int mark;
    struct node* prev;
    struct node* next;
} node;

typedef struct queue {
    unsigned int numberOfTimes;
    unsigned int total;
    node *front, *back;
} queue;

typedef struct cache {
    int valid;
    int layer;
    unsigned long int mark;
} cache;

node* newNode(long unsigned int mark) {
    node* newOne = (node*) malloc(sizeof(node));
    newOne->mark = mark;
    newOne->next = NULL;
    newOne->prev = NULL;
    return newOne;
}

void delete(queue* queuePtr, node* nodePtr) {
    if(queuePtr->front == NULL)
        return;

    if(queuePtr->front->mark == queuePtr->back->mark) {
        if (queuePtr->front->mark == nodePtr->mark) {
            queuePtr->front = NULL;
            queuePtr->back = NULL;
            queuePtr->numberOfTimes--;
            free(nodePtr);
            return;
        }
    }

    if(queuePtr->front->mark == nodePtr->mark) {
        queuePtr->front = queuePtr->front->next;
        if(queuePtr->back->mark == nodePtr->mark) {
            queuePtr->back = queuePtr->front;
        }
        queuePtr->numberOfTimes--;
        free(nodePtr);
        return;
    }

    if(queuePtr->back->mark == nodePtr->mark) {
        queuePtr->back = queuePtr->back->prev;
        queuePtr->back->next = NULL;
        queuePtr->numberOfTimes--;
        free(nodePtr);
        return;
    }

    nodePtr->next->prev = nodePtr->prev;
    nodePtr->prev->next = nodePtr->next;
    queuePtr->numberOfTimes--;
    free(nodePtr);
    return;
}

int least(queue* queuePtr, long unsigned int mark) {

    if(queuePtr->front == NULL) {
        node* nodePtr = newNode(mark);
        queuePtr->front = nodePtr;
        queuePtr->back = nodePtr;
        queuePtr->numberOfTimes++;
        return 0;
    }

    int exist = 0;

    node* temp = queuePtr->front;
    int i = 0;

    while(temp != NULL) {
        if(mark == temp->mark) {
            delete(queuePtr, temp);
            exist = 1;
            break;
        }

        temp = temp->next;
        i++;
    }

    if(exist == 0 && queuePtr->numberOfTimes >= queuePtr->total) {
        if (queuePtr->front == queuePtr->back) {queuePtr->front = NULL;}

        node* nodePtr = queuePtr->back;
        queuePtr->back = queuePtr->back->prev;
        free(nodePtr);
        if (queuePtr->back) {queuePtr->back->next = NULL;}
        queuePtr->numberOfTimes--;
    }

    node* nodePtr = newNode(mark);
    nodePtr->next = queuePtr->front;

    if(queuePtr->front == NULL) {
        queuePtr->front = nodePtr;
        queuePtr->back = nodePtr;
        queuePtr->numberOfTimes++;
    } else {
        queuePtr->front->prev = nodePtr;
        queuePtr->front = nodePtr;
        queuePtr->numberOfTimes++;
    }

    return exist;
}

cache** fifo(cache** cachePtr, long unsigned int mark, long unsigned int setNumber, int asso) {
    int i = 0, j = 0;

    for(i = 0; i < asso; i++) {
        if(cachePtr[setNumber][i].layer == asso) {
            cachePtr[setNumber][i].mark = mark;
            cachePtr[setNumber][i].layer = 1;
            for(j = 0; j < asso; j++) {
                if(j == i) {continue;}
                cachePtr[setNumber][j].layer++;
            }
            break;
        } else if(cachePtr[setNumber][i].valid == 0) {
            cachePtr[setNumber][i].valid = 1;
            cachePtr[setNumber][i].layer = 1;
            cachePtr[setNumber][i].mark = mark;
            for(j = 0; j < i; j++) {
                cachePtr[setNumber][j].layer++;
            }
            break;
        }
    }
    return cachePtr;
}

int main(int argc, char **argv) {
        if(argc != 7) {
            printf("Wrong inputs\n");
            exit(0);
        }

        FILE *fptr =  fopen(argv[6], "r");
        if(fptr == NULL) {
            printf("File not exist\n");
            exit(0);
        }

        int cacheSize = atoi(argv[1]);
        int blockSize = atoi(argv[5]);
        int prefetch = argv[3][1] - '0';
        char policy = argv[4][0];

        int asso, setNumber;

        if(strcmp(argv[2], "direct") == 0) {
            asso = 1;
            setNumber = cacheSize / blockSize;
        } else if(strcmp(argv[2], "assoc") == 0) {
            asso = cacheSize / blockSize;
            setNumber = 1;
        } else {
            asso = argv[2][6] - '0';
            setNumber = cacheSize / (blockSize * asso);
        }

        int offset = log2(blockSize);
        int set = log2(setNumber);

        int i = 0, j = 0;

        queue* Queue[setNumber];
        cache** Cache = (cache**) malloc(sizeof(cache*) * setNumber);

        if(policy == 'f'){
            for(i = 0; i < setNumber; i++){
                Cache[i] = (cache*) malloc(sizeof(cache) * asso);
                for(j = 0; j < asso; j++) {
                        Cache[i][j].layer = 0;
                        Cache[i][j].valid = 0;
                        Cache[i][j].mark = 0;
                }
            }
        } else if(policy == 'l') {
            for(i = 0; i < setNumber; i++) {
                Queue[i] = (queue*) malloc(sizeof(queue));
                Queue[i]->numberOfTimes = 0;
                Queue[i]->total = asso;
                Queue[i]->front = NULL;
                Queue[i]->back = NULL;
            }
        }

        char temp[30];
        char operation;
        long unsigned int address;
        long unsigned int blockIdentifier;
        long unsigned int setIdentifier;
        long unsigned int markIdentifier;
        while(fscanf(fptr, "%s %c %lx", temp, &operation, &address) != -1 && temp[0] != '#') {
            blockIdentifier = address >> offset;
            setIdentifier = ((1 << set) - 1) & blockIdentifier;
            markIdentifier = blockIdentifier >> set;

            int checker = 1;

            if(policy == 'l') {
                if(operation == 'W') {
                    checker = least(Queue[setIdentifier], markIdentifier);
                    if(checker) {
                        numberOfHits++;
                        numberOfWrites++;
                    } else {
                        numberOfWrites++;
                        numberOfMisses++;
                        numberOfReads++;

                        if(prefetch) {
                            address = address + blockSize;
                            blockIdentifier = address >> offset;
                            setIdentifier = ((1 << set) - 1) & blockIdentifier;
                            markIdentifier = blockIdentifier >> set;
                            checker = 0;

                            checker = least(Queue[setIdentifier], markIdentifier);

                            if(checker == 0)
                                numberOfReads++;
                        }
                    }
                } else if(operation == 'R') {

                    checker = least(Queue[setIdentifier], markIdentifier);

                    if(checker)
                        numberOfHits++;
                    else {
                        numberOfMisses++;
                        numberOfReads++;

                        if(prefetch){
                            address = address + blockSize;
                            blockIdentifier = address >> offset;
                            setIdentifier = ((1 << set) - 1) & blockIdentifier;
                            markIdentifier = blockIdentifier >> set;
                            checker = 0;

                            checker = least(Queue[setIdentifier], markIdentifier);

                            if(checker == 0)
                                numberOfReads++;
                        }
                    }
                }
            } else if(policy == 'f') {
                checker = 1;

                for(i = 0; i < asso; i++) {
                    if(Cache[setIdentifier][i].valid == 1 && (markIdentifier == Cache[setIdentifier][i].mark)) {
                        if(operation == 'W') {
                            numberOfHits++;
                            numberOfWrites++;
                            checker = 0;
                            break;
                        } else if (operation == 'R') {
                            numberOfHits++;
                            checker = 0;
                            break;
                        }
                    }
                }
                if(checker) {
                    if(operation == 'W') {
                        numberOfWrites++;
                        numberOfMisses++;
                        numberOfReads++;

                        Cache = fifo(Cache, markIdentifier, setIdentifier, asso);

                        if(prefetch) {
                            address = address + blockSize;
                            blockIdentifier = address >> offset;
                            setIdentifier = ((1 << set) - 1) & blockIdentifier;
                            markIdentifier = blockIdentifier >> set;
                            checker = 1;

                            for(i = 0; i < asso; i++) {
                                if(Cache[setIdentifier][i].valid == 1 && (markIdentifier == Cache[setIdentifier][i].mark)) {
                                    checker = 0;
                                    break;
                                }
                            }

                            if(checker) {
                                numberOfReads++;
                                Cache = fifo(Cache, markIdentifier, setIdentifier, asso);
                            }
                        }
                    } else if(operation == 'R') {
                        numberOfMisses++;
                        numberOfReads++;
                        if(policy == 'f')
                            Cache = fifo(Cache, markIdentifier, setIdentifier, asso);

                        if(prefetch) {
                            address = address + blockSize;
                            blockIdentifier = address >> offset;
                            setIdentifier = ((1 << set) - 1) & blockIdentifier;
                            markIdentifier = blockIdentifier >> set;
                            checker = 1;

                            for(i = 0; i < asso; i++) {
                                if(Cache[setIdentifier][i].valid == 1 && (markIdentifier == Cache[setIdentifier][i].mark)) {
                                    checker = 0;
                                    break;
                                }
                            }

                            if(checker) {
                                numberOfReads++;
                                if(policy == 'f')
                                    Cache = fifo(Cache, markIdentifier, setIdentifier, asso);
                            }
                        }
                    }
                }
            }
        }

        printf("Memory reads: %d\n", numberOfReads);
        printf("Memory writes: %d\n", numberOfWrites);
        printf("Cache hits: %d\n", numberOfHits);
        printf("Cache misses: %d\n", numberOfMisses);

    return 0;
}
