
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int count(int row, int col, int h, int w, int **bef);
void createGrid(int **hold, char **aft, int h, int w);
void printGrid(char **aft, int h, int w);
void nextGen(int **bef, int h, int w);

int main(int argc, char **argv){

	if(argc < 3){
	return 0;
}

	int n = atoi(argv[1]);

	FILE *src = fopen(argv[2], "r");

	if(src == NULL)
	return 0;

	int h,w;

	fscanf(src, "%d %d", &h, &w);

	char **aft ;
	int **bef;
	int x, i, j;

	bef = (int**)malloc(h * sizeof(int*));
	aft = (char**)malloc(h * sizeof(char*));

	for(x = 0; x < h; x++) {
		bef[x] = (int*)malloc(sizeof(int) * w);
		aft[x] = (char*)malloc(sizeof(char) * w);

	}

	for(i = 0; i < h; i++) {
		for(j = 0; j < w; j++) {

		char c;
		fscanf(src, " %c", &c);
		if(c == '*') {

		bef[i][j] = 1;

		} else {

		bef[i][j] = 0;

	     }
	}
   }
	int g;
	for(g = 0; g < n; g++)
	nextGen(bef, h, w);

	createGrid(bef, aft, h, w);

	printGrid(aft, h, w);

	for(i = 0; i < h; i++) {
		free(bef[i]);
		free(aft[i]);

	}

	free(bef);
	free(aft);

	return 0;
}

int count(int row, int col, int h, int w, int **bef) {

	int i, j, pop = 0;
    for(i = row - 1; i < row + 2; i++) {
        for(j = col - 1; j < col + 2; j++) {
            if (i == row && j == col) {
                continue;
            }
            if (i > -1 && j > -1 && i < h && j < w) {
                pop += bef[i][j];
            }
        }
    }
    return pop;
}

void createGrid(int **hold, char **aft, int h, int w){

	int x, y;
	for(x = 0; x < h; x++){
	for(y = 0; y < w; y++){
		if(hold[x][y] == 0)
		aft[x][y] = '.';
		else
		aft[x][y] = '*';
	}
}
}

void printGrid(char **aft, int h, int w){

	int i, j;
	for(i = 0; i < h; i++){
	for(j = 0; j < w; j++){

		printf("%c",aft[i][j]);
	}
	printf("\n");
    }
}

void nextGen(int **bef, int h, int w){

	int temp[h][w];
	int x, y;
	for(x = 0; x < h ; x++){
		for(y = 0; y < w; y++){


		int pop = count(x, y, h, w, bef);

		if((bef[x][y] == 1) && (pop < 2))
			temp[x][y] = 0;

		else if((bef[x][y] == 1) && (pop > 3))
			temp[x][y] = 0;

		else if((bef[x][y] == 0) && (pop == 3))
			temp[x][y] = 1;

		else
			temp[x][y] = bef[x][y];

	}
    }
	for(x = 0; x < h; x++)
	for(y = 0; y < w; y++)
		bef[x][y] = temp[x][y];

}
