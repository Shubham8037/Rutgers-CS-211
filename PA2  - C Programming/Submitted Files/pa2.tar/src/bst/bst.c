#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

typedef struct node{

	int pointer;
	struct node *head;
	struct node *data;
}

node;

node* create(int pointer) {

	node *newNode = (node *) malloc(sizeof(node));
	newNode->pointer = pointer;
	newNode->head = NULL;
	newNode->data = NULL;

	return newNode;

}

node* in(node* a, int pointer){

	if(a == NULL) {

		a = create(pointer);
		printf("inserted\n");

	} else if(a->pointer == pointer) {

		printf("duplicate\n");
		return a;

	} else {

		if(a->pointer > pointer) {
		
			a->head = in(a->head,pointer);

		}else{

			a->data = in(a->data,pointer);

		}
	
	}
	
	return a;

}

void find(node* a, int pointer) {

	if(a == NULL) {

		printf("absent\n");
		return;

	}else{

		if (a->pointer == pointer){

			printf("present\n");
			return;

		}

		if(a->pointer < pointer)
			find(a->data,pointer);

		else
			find(a->head,pointer);
	}
}

node* smal(node* small){

	node* a = small;

	while(a->head != NULL)
		a = a->head;

	return a;
}


node* del(node* a, int pointer){

	if(a == NULL){
		printf("absent\n");
		return a;
	}

	if(pointer < a->pointer){
		a->head = del(a->head,pointer);

	} else if(pointer > a->pointer) {
		a->data = del(a->data,pointer);

	} else {

		if(a->head == NULL){
			node *newNode = a->data;
			free(a);

			printf("deleted\n");
			return newNode;

		} else if(a->data == NULL){
			node *newNode = a->head;
			free(a);

			printf("deleted\n");
			return newNode;
		}

		node *newNode = smal(a->data);

		a->pointer = newNode->pointer;

		a->data = del(a->data, newNode->pointer);
	}
	return a;
}

void print(node* a){

	if(a == NULL){
		return;
	}
	printf("(");
	print(a->head);
	printf("%d", a->pointer);
	print(a->data);
	printf(")");
}

int main(){

	char this;
	int x;

	node *a = NULL;
	char line[100];


	while(fgets(line,sizeof(line),stdin)){
		if(sscanf(line, " %c %d", &this, &x) == 2) {

			if(this == 'i') {
				a = in(a, x);

			} else if(this == 'd') {
				a = del(a, x);

			} else if(this == 's'){
				find(a, x);

			}

		} if(sscanf(line, " %c", &this) == 1){

			if(this == 'p')
				print(a);

		} else {

			break;
		}

	}


	return 0;
}

