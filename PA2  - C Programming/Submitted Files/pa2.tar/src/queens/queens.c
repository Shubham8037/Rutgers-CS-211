
#include<stdio.h>
#include<stdlib.h>

enum board_options{ empty , existing_q , captured , place_q , place_wq , place_temp };

int _squares(int *b)
{
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if(*( b+8*i+j ) ==existing_q )
			{
				int numb;
				for(numb=0;numb<8;numb++)
				{
					if(numb!=i)
					{
						if( *( b+8*numb+j ) == existing_q )
							return -1;
						*( b+8*numb+j )=captured;
					}
				}
				int col;
				for(col=0;col<8;col++)
				{
					if(col!=j)
					{
						if( *( b+8*i+col ) == existing_q )
							return -1;
						*( b+8*i+col )=captured;
					}
				}

				numb=i+1;
				col=j+1;
				while(numb<8 && col<8)
				{
					if( *( b+8*numb+col ) == existing_q )
						return -1;
					*( b+8*numb+col )=captured;
					numb++;
					col++;
				}

				numb=i-1;
				col=j-1;
				while(numb>=0 && col>=0)
				{
					if( *( b+8*numb+col ) == existing_q )
						return -1;
					*( b+8*numb+col )=captured;
					numb--;
					col--;
				}

				numb=i+1;
				col=j-1;
				while(numb<8 && col>=0)
				{
					if( *( b+8*numb+col ) == existing_q )
						return -1;
					*( b+8*numb+col )=captured;
					numb++;
					col--;
				}

				numb=i-1;
				col=j+1;
				while(numb>=0 && col<8)
				{
					if( *( b+8*numb+col ) == existing_q )
						return -1;
					*( b+8*numb+col )=captured;
					numb--;
					col++;
				}

			}
		}
	}

	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if(*( b+8*i+j ) == empty )
				*( b+8*i+j ) = place_q;
		}
	}

	return 1;
}

int check_warrior(int *b,int row,int col)
{
	int r,c;

	r=row-2;
	if(r>=0)
	{
		c=col-1;
		if(c>=0)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
		c=col+1;
		if(c<8)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
	}

	r=row-1;
	if(r>=0)
	{
		c=col-2;
		if(c>=0)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
		c=col+2;
		if(c<8)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
	}


	r=row+2;
	if(r<8)
	{
		c=col-1;
		if(c>=0)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
		c=col+1;
		if(c<8)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
	}

	r=row+1;
	if(r<8)
	{
		c=col-2;
		if(c>=0)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
		c=col+2;
		if(c<8)
		{
			if( *(b+8*r+c)==existing_q )
				return 0;
		}
	}
	return 1;

}

void warrior(int *b)
{
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if( *( b+8*i+j )==place_q )
			{
				if(check_warrior(b,i,j))
				{
					*( b+8*i+j )=place_wq;
				}
			}
		}
	}
}

int check_next(int *b,int r,int c)
{
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if( *(b+8*i+j)==captured || *(b+8*i+j)==existing_q )
				continue;
			if( i==r || j==c )
				continue;
			if( abs(r-i)==abs(c-j) )
				continue;
			return 1;
		}
	}
	return 0;

}


int place_double(int *b)
{
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if( *(b+8*i+j)==place_q || *(b+8*i+j)==place_wq )
			{
				int temp_ij=*( b+8*i+j );
				*( b+8*i+j )=place_temp;
				if(check_next(b,i,j))
				{
					*( b+8*i+j )=temp_ij;
					return 1;
				}
				*( b+8*i+j )=temp_ij;
			}
		}
	}
	return 0;
}

int count_new_q(int *b)
{
	int count=0;
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			if( *(b+8*i+j)==place_q || *(b+8*i+j)==place_wq )
				count++;
		}
	}
	return count;

}


void additional(int *b)
{
	int c=count_new_q(b);
	if(c==0)
	{
		printf("Zero\n");
		return;
	}

	if(place_double(b)==0)
	{
		printf("One\n");
	}
	else
		printf("Two or more\n");

}


void print_board(int *b)
{
	int temp;
	int i;
	for(i=0;i<8;i++)
	{
		int j;
		for(j=0;j<8;j++)
		{
			temp=*(b+8*i+j);
			if(temp==place_q)
				printf("q");
			else if(temp==existing_q)
				printf("Q");
			else if(temp==place_wq)
				printf("w");
			else
				printf(".");


		}
		printf("\n");
	}
}


int main(int argc,char* argv[])
{
	FILE* fptr=fopen(argv[argc-1],"r");
	if (fptr == NULL)
	{
		printf("Cannot open file \n");
		exit(0);
	}

	int board[8][8];

	char ch = fgetc(fptr);
	int count =0;
	while (ch != EOF)
	{
		if(ch=='.')
		{
			board[count/8][count%8]=empty;
			count++;
		}
		else if(ch=='Q')
		{
			board[count/8][count%8]=existing_q;
			count++;
		}

		ch = fgetc(fptr);
	}
	fclose(fptr);

	int possible=_squares(&board[0][0]);

	if(possible==-1)
	{
		printf("Invalid");
		exit(0);
	}


	if( (argc==3 && *(argv[1])=='-') || ( (argc==4 && ( *(argv[1])=='-' || *(argv[2])=='-' ) ) ) )
	{
		warrior(&board[0][0]);
	}
	print_board(&board[0][0]);

	if( (argc==3 && *(argv[1])=='+') || ( (argc==4 && ( *(argv[1])=='+' || *(argv[2])=='+' ) ) ) )
	{
		additional(&board[0][0]);
	}






	return 0;
}











