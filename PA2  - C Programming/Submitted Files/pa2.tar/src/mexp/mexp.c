//mexp.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ** makeSQMatrix(rows)
{
    int **SQMat;
    int i;
    SQMat = (int **) malloc(rows*rows*sizeof(int*));
    for(i=0; i<rows; i++)
    {
        SQMat[i] = (int*) malloc(rows* sizeof(int));
    }
    return SQMat;
}



int main(int argc, char **argv)
{
    int i,j,z,x,k; //looping purposes
    int item;
    int exp;
    int **originalMatrix;
    int **EMatrix;
    int Sum;
    int**Copy;
    FILE *file = fopen(argv[1], "r");
    fscanf(file, "%d", &k);
//printf("This is how many rows and columns we have:\n%d\n", k);
//printf("this is the original matrix: \n");

    originalMatrix = makeSQMatrix(k);
    EMatrix = makeSQMatrix(k);
    Copy = makeSQMatrix(k);
    for(i=0; i<k; i++)
    {
        for(j=0; j<k; j++)
        {
            fscanf(file, "%d\t", &item);
            if(file == NULL)
            {
                printf("%d\n", k);
            }

            originalMatrix[i][j] = item;
            Copy[i][j] = item;
            //printf("%d\t", originalMatrix[i][j]);
        }
        //printf("\n");
    }


    for(i=0; i<k; i++)
    {
        for(j=0; j<k; j++)
        {
            Copy[i][j] = 0;
        }
    }

    for(i=0; i<k; i++)
    {
        for(j=0; j<k; j++)
        {
            Copy[i][j] += originalMatrix[i][j];
        }
    }



    fscanf(file, "%d", &exp);
//printf("This matrix will be exponentiated to the power of %d\n", exp);

//in case of exp being 0:

    int **OneMatrix = makeSQMatrix(k);
    if(exp == 0)
    {
        for(i=0; i<k; i++)
        {
            for(j=0; j<k; j++)
            {
                OneMatrix[i][j] = 1;
                printf("%d", OneMatrix[i][j]);
                if (j< k-1)
                    printf(" ");
            }
            printf("\n");
        }
        return 0;
    }

//in case of exp being 1:

    if(exp==1)
    {
        for(i=0; i<k; i++)
        {
            for(j=0; j<k; j++)
            {
                printf("%d", originalMatrix[i][j]);
                if (j< k-1)
                    printf(" ");
            }
            printf("\n");
        }
        return 0;
    }

//Time to Exponentiate
    for(z=1; z<exp; z++)
    {
        for(i=0; i<k; i++)
        {
            for(j=0; j<k; j++)
            {
                Sum=0;
                for(x=0; x<k; x++)
                {
                    Sum= Sum+ originalMatrix[i][x] * Copy[x][j];
                }

                EMatrix[i][j] = Sum;

            }

        }
        for(i=0; i<k; i++)
        {
            for(j=0; j<k; j++)
            {
                Copy[i][j] = EMatrix[i][j];
            }
        }


    }

    for(i=0; i<k; i++)
    {
        for(j=0; j<k; j++)
        {
            EMatrix[i][j] = Copy[i][j];
        }
    }



    for(i=0; i<k; i++)
    {
        for(j=0; j<k; j++)
        {
            printf("%d", EMatrix[i][j]);
            if(j < k-1)
                printf(" ");
        }
        printf("\n");
    }


    return 0;
}
