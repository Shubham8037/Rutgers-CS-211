#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
struct Node
{

    double number;
    struct Node *next;

}*head;

void addNode(double num)
{
    struct Node* temp;
    temp=(struct Node*)malloc(sizeof(struct Node));
    temp->number=num;
    if(head==NULL)
    {
        head=temp;
        head->next=NULL;
    }
    else
    {
        temp->next=head;
        head=temp;
    }
}
void standardDeviation()
{
    int length=0;
    struct Node* temp=head;
    if(temp==NULL)
        length=0;

    double standardDeviation=0;
    double mean=0;
    double sum=0;
//	struct Node* temp=head;
    while(temp!=NULL)
    {
        sum+=temp->number;
        temp=temp->next;
        length++;
    }

    mean=sum/length;

    double numerator=0;
    temp=head;
    while(temp!=NULL)
    {
        numerator+=pow((temp->number-mean),2);
        temp=temp->next;
    }
    numerator=sqrt(numerator);
    standardDeviation=numerator/sqrt(length);

    printf("mean: %.0f",mean);
    printf("\n");
    printf("stddev: %.0f", standardDeviation);

}


void display()
{
    struct Node* temp=head;
    if(temp==NULL)
    {
        return;
    }
    while(temp!=NULL)
    {
        printf("%lf ",temp->number);
        temp=temp->next;
    }

}



struct Node* head=NULL;
int main()
{

    double number=0;
    double sum=0;
    int count=0;
    while(scanf(" %lf",&number)==1)
    {

        sum+=number;
        addNode(number);
        count++;
    }
    if(count==0)
    {
        printf("no Values");

    }

    count++;
    standardDeviation();
    return 0;
}
