#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
 
int gcdcalc( int a, int b ){

	int y; //Remainder
			
	while(y != 0 || y != 1){
		
		y = a%b;
		
		if(y == 0){
		
			return b;
			break;
	
		}
		
		a = b;
		b = y;	
	
	}

	return y;

}



int main(int argc, const char* argv[]){
	
	if(argc > 3){
	
		printf("BAD INPUT!! RETRY... \n");
		return 0;
	
	}
	
	int num1;
	int num2;
	int num3;
	
	num1 = atoi(argv[1]);
	num2 = atoi(argv[2]);
	num3 = 0;
		
	if(num2 > num1){
	
		num3 = num2;
		num2 = num1;
		num1 = num3;
		
	}
	
	printf("%d\n",gcdcalc(num1,num2));
	fflush(stdin);
	return 0;

}
