#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char* rot13calc( char* str, int len ){
	
	int i;
	char* z;
	int asc;		//Ascii Value
	
	z = (char*)malloc((1+len)*sizeof(char));
	
	for( i = 0 ; i < len ; i++){
		
		asc = toascii(str[i]);
		
		if(asc>96&&asc<110){
		
			asc+=13;
		
		}else if(asc>109&&asc<123){
		
			asc-=13;
		
		}else if(asc>64&&asc<78){
		
			asc+=13;
		
		}else if(asc>77&&asc<91){
		
			asc-=13;
		
		}
		
		printf("%c",(char)asc);
	
	}
	
	return z;
	
}



int main(int argc, char* argv[]){
	
	if(argc > 2){

		printf("TOO MANY ARGUMENTS, RETRY...\n");
		return 0;

	}
	
	char* string = argv[1];
	int length = strlen(string);
	char* convert = rot13calc(string,length);
	printf("%s\n",convert);
	free(convert);
	fflush(stdin);
	return 0;
	
}
