#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char* rlecalc( char* str ){
	
	char*y;
	char*z;
	int CharCount;
	
	for(y=str, z=str ; *y ; y++){
	
		CharCount = 1;
		z[0] = y[0];
		z+=1;
		
		while(y[0] == y[1]){
		
			y+=1;
			CharCount+=1;
			
		}if(CharCount > 1){
		
			z[0] = '0'+CharCount;
			z+=1;
		
		} if(CharCount == 1){
		
			z[0] = '0'+CharCount;
			z+=1;
		
		}
	
	}
	
	z[0] = 0;
	return str;
	
}



int main(int argc, char* argv[]){
	
	if(argc > 2){
	
		printf("TOO MANY ARGUMENTS, RETRY...\n");
		return 0;
	
	}
	
	int i; //For for-loop
	char* string = argv[1];
	int length = strlen(string);
	
	for(i=0;i<length;i++){
	
		if(string[i] == '0' || string[i] == '1' || string[i] == '2' || string[i] == '3' || string[i] == '4' || string[i] == '5' || string[i] == '6' || string[i] == '7' || string[i] == '8' || string[i] == '9'){
		
			printf("error\n");
			return 0;
		
		}
	
	}
	
	printf("%s\n",rlecalc(string));
	fflush(stdin);
	return 0;
	
}
